class Messenger {
    constructor() {
        this.currentUser = null;
        this.currentScreen = 'auth';
        this.replyingTo = null;
        this.audioContext = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.init();
    }
    
    async init() {
        await this.checkAuth();
        this.setupEventListeners();
        this.loadMessages();
        setInterval(() => this.loadMessages(), 3000);
        setInterval(() => this.updateOnlineStatus(), 60000);
    }

    async checkAuth() {
        try {
            const response = await fetch('/api/check_auth');
            const data = await response.json();
            
            if (data.authenticated) {
                this.currentUser = data.user;
                if (!this.currentUser.description || this.currentUser.description === '') {
                    this.showScreen('profile');
                } else {
                    this.showScreen('chat');
                }
            } else {
                this.showScreen('auth');
            }
        } catch (error) {
            console.error('Ошибка проверки авторизации:', error);
            this.showScreen('auth');
        }
    }

    setupEventListeners() {
        // Настройка профиля
        document.getElementById('avatar-upload').addEventListener('change', (e) => this.uploadAvatar(e));
        document.querySelectorAll('.color-option').forEach(option => {
            option.addEventListener('click', (e) => this.selectColor(e));
        });
        
        document.getElementById('save-profile').addEventListener('click', () => this.saveProfile());
        
        // Чат
        document.getElementById('send-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('message-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
        
        document.getElementById('photo-btn').addEventListener('click', () => this.uploadPhoto());
        document.getElementById('voice-btn').addEventListener('click', () => this.toggleVoiceRecording());
        document.getElementById('cancel-reply').addEventListener('click', () => this.cancelReply());
        
        // Модальные окна
        document.getElementById('participants-btn').addEventListener('click', () => this.showParticipants());
        document.getElementById('search-btn').addEventListener('click', () => this.showSearch());
        document.getElementById('mentions-btn').addEventListener('click', () => this.showMentions());
        document.getElementById('edit-profile-btn').addEventListener('click', () => this.editProfile());
        document.getElementById('logout-btn').addEventListener('click', () => this.logout());
        
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => this.closeModal(e));
        });
        
        // Поиск
        document.getElementById('search-execute-btn').addEventListener('click', () => this.executeSearch());
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.executeSearch();
        });
        
        // Упоминания
        document.getElementById('mark-read-btn').addEventListener('click', () => this.markMentionsAsRead());
    }

    async uploadAvatar(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (file.size > 2 * 1024 * 1024) {
            this.showError('Файл слишком большой (макс. 2MB)');
            return;
        }

        const formData = new FormData();
        formData.append('avatar', file);

        try {
            const response = await fetch('/api/upload/avatar', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            
            if (data.success) {
                // Обновляем превью аватара
                const avatarPreview = document.getElementById('avatar-preview');
                avatarPreview.src = `/static/avatars/${data.filename}?t=${Date.now()}`;
                this.showError('Аватар успешно загружен', 'success');
            } else {
                this.showError(data.error);
            }
        } catch (error) {
            this.showError('Ошибка загрузки аватара');
        }
    }

    selectColor(e) {
        document.querySelectorAll('.color-option').forEach(o => o.classList.remove('selected'));
        e.currentTarget.classList.add('selected');
    }

    async saveProfile() {
        const selectedColor = document.querySelector('.color-option.selected').dataset.color;
        const description = document.getElementById('profile-description').value;
        const avatar = document.getElementById('avatar-preview').src.split('/').pop().split('?')[0];

        try {
            const response = await fetch('/api/profile', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    avatar: avatar,
                    color: selectedColor,
                    description: description
                })
            });

            const data = await response.json();
            
            if (data.success) {
                this.currentUser.avatar = avatar;
                this.currentUser.color = selectedColor;
                this.currentUser.description = description;
                this.showScreen('chat');
            } else {
                this.showError(data.error);
            }
        } catch (error) {
            this.showError('Ошибка сохранения профиля');
        }
    }

    async sendMessage() {
        const input = document.getElementById('message-input');
        const text = input.value.trim();

        if (!text && !this.replyingTo) return;

        try {
            const response = await fetch('/api/messages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: text,
                    reply_to: this.replyingTo,
                    type: 'text'
                })
            });

            const data = await response.json();
            
            if (data.success) {
                input.value = '';
                this.cancelReply();
                this.loadMessages();
            } else {
                this.showError(data.error);
            }
        } catch (error) {
            this.showError('Ошибка отправки сообщения');
        }
    }

    async loadMessages() {
        try {
            const response = await fetch('/api/messages');
            const data = await response.json();
            
            const messagesContainer = document.getElementById('messages');
            if (!messagesContainer) return;
            
            messagesContainer.innerHTML = '';
            
            if (data.messages && data.messages.length > 0) {
                data.messages.forEach(msg => {
                    const messageElement = this.createMessageElement(msg);
                    messagesContainer.appendChild(messageElement);
                });
            }
            
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } catch (error) {
            console.error('Ошибка загрузки сообщений:', error);
        }
    }

    createMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message';
        
        if (this.currentUser && message.user_id === this.currentUser.id) {
            messageDiv.classList.add('own-message');
        }

        const avatarSrc = `/static/avatars/${message.avatar || 'default.png'}?t=${Date.now()}`;

        let messageContent = '';
        
        if (message.reply_to) {
            messageContent += `
                <div class="reply-to">
                    <span class="reply-username">Ответ на сообщение</span>
                    <span class="reply-text">${message.reply_to}</span>
                </div>
            `;
        }

        messageContent += `
            <div class="message-header">
                <span class="username" style="color: ${this.getColorCode(message.color)}">${message.username || 'Неизвестный'}</span>
                <span class="timestamp">${this.formatTime(message.timestamp)}</span>
            </div>
        `;

        if (message.type === 'text') {
            messageContent += `<div class="message-text">${this.parseMentions(message.text || '')}</div>`;
        } else if (message.type === 'photo') {
            messageContent += `
                <div class="photo-message">
                    <img src="/static/photos/${message.text}" alt="Фото" class="message-photo-img">
                </div>
            `;
        } else if (message.type === 'voice') {
            messageContent += `
                <div class="voice-message">
                    <button class="voice-play-btn" onclick="messenger.playVoiceMessage('${message.text}')">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="5,3 19,12 5,21"></polygon>
                        </svg>
                    </button>
                    <div class="voice-waveform">
                        ${this.generateWaveform()}
                    </div>
                    <span class="voice-duration">${message.duration || '0:05'}</span>
                </div>
            `;
        }

        messageDiv.innerHTML = `
            <img src="${avatarSrc}" alt="Аватар" class="message-avatar" onclick="showUserProfile('${message.user_id}')">
            <div class="message-content" data-message-id="${message.id}">
                ${messageContent}
            </div>
        `;

        const avatar = messageDiv.querySelector('.message-avatar');
        const username = messageDiv.querySelector('.username');
        avatar.addEventListener('click', () => this.showUserProfile(message.user_id));
        username.addEventListener('click', () => this.showUserProfile(message.user_id));

        messageDiv.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.setReplyTo(message);
        });

        return messageDiv;
    }

    findMessageById(messageId) {
        const messages = document.querySelectorAll('.message-content');
        for (const messageEl of messages) {
            if (messageEl.dataset.messageId === messageId) {
                return {
                    username: messageEl.querySelector('.username')?.textContent || 'Неизвестный',
                    text: messageEl.querySelector('.message-text')?.textContent || ''
                };
            }
        }
        return null;
    }

    async playVoiceMessage(filename) {
        try {
            const audio = new Audio(`/api/voice/${filename}`);
            audio.play().catch(error => {
                console.error('Ошибка воспроизведения:', error);
                this.showError('Не удалось воспроизвести голосовое сообщение');
            });
        } catch (error) {
            this.showError('Ошибка воспроизведения голосового сообщения');
        }
    }

    async toggleVoiceRecording() {
        if (this.isRecording) {
            this.stopVoiceRecording();
        } else {
            await this.startVoiceRecording();
        }
    }

    async startVoiceRecording() {
        try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                this.showError('Ваш браузер не поддерживает запись голоса');
                return;
            }

            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: true
            });
            
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = async () => {
                if (this.audioChunks.length > 0) {
                    const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
                    await this.uploadVoiceMessage(audioBlob);
                }
                stream.getTracks().forEach(track => track.stop());
            };
            
            this.mediaRecorder.start();
            this.isRecording = true;
            document.getElementById('voice-btn').classList.add('recording');
            this.showError('Идет запись... Нажмите еще раз чтобы остановить', 'success');
            
        } catch (error) {
            console.error('Ошибка записи:', error);
            this.showError('Ошибка доступа к микрофону. Проверьте разрешения');
        }
    }

    stopVoiceRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            document.getElementById('voice-btn').classList.remove('recording');
        }
    }

    async uploadVoiceMessage(audioBlob) {
        const formData = new FormData();
        formData.append('voice', audioBlob, 'voice_message.webm');

        try {
            const response = await fetch('/api/upload/voice', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            
            if (data.success) {
                const messageResponse = await fetch('/api/messages', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        text: data.filename,
                        type: 'voice',
                        duration: data.duration || 5
                    })
                });

                const messageData = await messageResponse.json();
                
                if (messageData.success) {
                    this.loadMessages();
                    this.showError('Голосовое сообщение отправлено', 'success');
                } else {
                    this.showError(messageData.error);
                }
            } else {
                this.showError(data.error);
            }
        } catch (error) {
            console.error('Ошибка отправки голоса:', error);
            this.showError('Ошибка отправки голосового сообщения');
        }
    }

    parseMentions(text) {
        if (!text) return '';
        return text.replace(/@(\w+)/g, '<span class="mention" onclick="mentionUser(\'$1\')">@$1</span>');
    }

    generateWaveform() {
        const heights = [20, 60, 30, 80, 45, 70, 25, 55];
        return heights.map(h => `<div class="wave-bar" style="height: ${h}%;"></div>`).join('');
    }

    async showUserProfile(userId) {
        try {
            const response = await fetch(`/api/user/${userId}`);
            const user = await response.json();
            
            const modal = document.getElementById('user-profile-modal');
            const content = document.getElementById('user-profile-content');
            
            content.innerHTML = `
                <img src="/static/avatars/${user.avatar || 'default.png'}?t=${Date.now()}" alt="Аватар" class="profile-avatar">
                <h4 class="profile-username" style="color: ${this.getColorCode(user.color)}">${user.username || 'Неизвестный'}</h4>
                <p class="profile-description">${user.description || 'Нет описания'}</p>
                <p class="profile-joined">Участник с ${new Date(user.created_at).toLocaleDateString()}</p>
            `;
            
            modal.style.display = 'flex';
        } catch (error) {
            this.showError('Ошибка загрузки профиля');
        }
    }

    setReplyTo(message) {
        this.replyingTo = message.id;
        const preview = document.getElementById('reply-preview');
        preview.style.display = 'flex';
        preview.querySelector('.reply-to-username').textContent = message.username || 'Неизвестный';
        preview.querySelector('.reply-to-text').textContent = (message.text || '').substring(0, 50) + (message.text && message.text.length > 50 ? '...' : '');
    }

    cancelReply() {
        this.replyingTo = null;
        document.getElementById('reply-preview').style.display = 'none';
    }

    async uploadPhoto() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            if (file.size > 5 * 1024 * 1024) {
                this.showError('Файл слишком большой (макс. 5MB)');
                return;
            }

            const formData = new FormData();
            formData.append('photo', file);

            try {
                const response = await fetch('/api/upload/photo', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                
                if (data.success) {
                    const messageResponse = await fetch('/api/messages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            text: data.filename,
                            type: 'photo'
                        })
                    });

                    const messageData = await messageResponse.json();
                    
                    if (messageData.success) {
                        this.loadMessages();
                    } else {
                        this.showError(messageData.error);
                    }
                } else {
                    this.showError(data.error);
                }
            } catch (error) {
                this.showError('Ошибка загрузки фото');
            }
        };
        
        input.click();
    }

    async showParticipants() {
        try {
            const response = await fetch('/api/users');
            const data = await response.json();
            
            const modal = document.getElementById('participants-modal');
            const list = document.getElementById('participants-list');
            if (!list) return;
            
            list.innerHTML = '';
            
            if (data.users && data.users.length > 0) {
                data.users.forEach(user => {
                    const participant = document.createElement('div');
                    participant.className = 'participant';
                    participant.innerHTML = `
                        <img src="/static/avatars/${user.avatar || 'default.png'}?t=${Date.now()}" alt="Аватар">
                        <div class="participant-info">
                            <span class="participant-name" style="color: ${this.getColorCode(user.color)}">${user.username || 'Неизвестный'}</span>
                            <span class="participant-status">${this.isOnline(user) ? 'онлайн' : 'не в сети'}</span>
                        </div>
                    `;
                    
                    participant.addEventListener('click', () => this.showUserProfile(user.id));
                    list.appendChild(participant);
                });
            }
            
            const countElement = document.getElementById('participants-count');
            if (countElement) {
                countElement.textContent = `Участников: ${data.users ? data.users.length : 0}`;
            }
            
            modal.style.display = 'flex';
        } catch (error) {
            this.showError('Ошибка загрузки участников');
        }
    }

    async executeSearch() {
        const query = document.getElementById('search-input').value.trim();
        if (!query) {
            this.showError('Введите текст для поиска');
            return;
        }

        try {
            const response = await fetch('/api/search/messages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: query })
            });

            const data = await response.json();
            const resultsContainer = document.getElementById('search-results');
            if (!resultsContainer) return;
            
            resultsContainer.innerHTML = '';
            
            if (!data.results || data.results.length === 0) {
                resultsContainer.innerHTML = '<p class="no-results">Сообщения не найдены</p>';
                return;
            }

            data.results.forEach(msg => {
                const result = document.createElement('div');
                result.className = 'search-result';
                result.innerHTML = `
                    <div class="result-header">
                        <span class="result-username">${msg.username || 'Неизвестный'}</span>
                        <span class="result-time">${this.formatTime(msg.timestamp)}</span>
                    </div>
                    <div class="result-text">${msg.text || ''}</div>
                `;
                resultsContainer.appendChild(result);
            });
        } catch (error) {
            console.error('Ошибка поиска:', error);
            this.showError('Ошибка поиска');
        }
    }

    async showMentions() {
        try {
            const response = await fetch('/api/mentions');
            const data = await response.json();
            
            const modal = document.getElementById('mentions-modal');
            const list = document.getElementById('mentions-list');
            if (!list) return;
            
            list.innerHTML = '';
            
            if (!data.mentions || data.mentions.length === 0) {
                list.innerHTML = '<p class="no-mentions">Упоминаний нет</p>';
                return;
            }

            data.mentions.forEach(mention => {
                const mentionElement = document.createElement('div');
                mentionElement.className = `mention-item ${mention.read ? 'read' : 'unread'}`;
                mentionElement.dataset.mentionId = mention.id;
                
                mentionElement.innerHTML = `
                    <div class="mention-header">
                        <span class="mention-username">${mention.mentioning_username || 'Неизвестный'}</span>
                        <span class="mention-time">${this.formatTime(mention.timestamp)}</span>
                    </div>
                    <div class="mention-text">${mention.message_text || 'Сообщение'}</div>
                    ${!mention.read ? '<div class="mention-badge">NEW</div>' : ''}
                `;
                list.appendChild(mentionElement);
            });
            
            modal.style.display = 'flex';
        } catch (error) {
            console.error('Ошибка загрузки упоминаний:', error);
            this.showError('Ошибка загрузки упоминаний');
        }
    }

    async markMentionsAsRead() {
        try {
            const unreadMentions = Array.from(document.querySelectorAll('.mention-item.unread'))
                .map(item => item.dataset.mentionId)
                .filter(id => id);
                
            if (unreadMentions.length > 0) {
                const response = await fetch('/api/mentions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mention_ids: unreadMentions })
                });
                
                if (response.ok) {
                    this.showMentions(); // Обновляем список
                }
            }
        } catch (error) {
            this.showError('Ошибка отметки упоминаний');
        }
    }

    async editProfile() {
        this.showScreen('profile');
        document.getElementById('profile-description').value = this.currentUser.description || '';
        
        document.querySelectorAll('.color-option').forEach(opt => {
            opt.classList.toggle('selected', opt.dataset.color === this.currentUser.color);
        });
    }

    async logout() {
        try {
            await fetch('/api/logout', { method: 'POST' });
            this.currentUser = null;
            this.showScreen('auth');
        } catch (error) {
            this.showError('Ошибка выхода');
        }
    }

    async updateOnlineStatus() {
        if (this.currentUser) {
            try {
                await fetch('/api/profile', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        avatar: this.currentUser.avatar,
                        color: this.currentUser.color,
                        description: this.currentUser.description
                    })
                });
            } catch (error) {
                console.error('Ошибка обновления статуса:', error);
            }
        }
    }

    showScreen(screenName) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        const screenElement = document.getElementById(`${screenName}-screen`);
        if (screenElement) {
            screenElement.classList.add('active');
        }
        this.currentScreen = screenName;
    }

    showError(message, type = 'error') {
        const errorContainer = document.getElementById('auth-error') || 
                              document.getElementById('profile-error') ||
                              document.getElementById('chat-error');
                              
        if (errorContainer) {
            errorContainer.textContent = message;
            errorContainer.className = `error-message ${type}`;
            errorContainer.style.display = 'block';
            
            setTimeout(() => {
                errorContainer.style.display = 'none';
            }, 5000);
        } else {
            alert(message);
        }
    }

    formatTime(timestamp) {
        try {
            return new Date(timestamp).toLocaleTimeString();
        } catch {
            return '00:00';
        }
    }

    getColorCode(colorName) {
        const colors = {
            'blue-normal': '#2196F3', 'blue-light': '#64B5F6', 'blue-dark': '#1565C0',
            'red-normal': '#F44336', 'red-light': '#EF5350', 'red-dark': '#C62828',
            'green-normal': '#4CAF50', 'green-light': '#66BB6A', 'green-dark': '#2E7D32',
            'purple-normal': '#9C27B0', 'purple-light': '#AB47BC', 'purple-dark': '#6A1B9A',
            'orange-normal': '#FF9800', 'orange-light': '#FFB74D', 'orange-dark': '#E65100',
            'teal-normal': '#009688', 'teal-light': '#4DB6AC', 'teal-dark': '#00695C',
            'pink-normal': '#E91E63', 'pink-light': '#F06292', 'pink-dark': '#AD1457',
            'amber-normal': '#FFC107', 'amber-light': '#FFCA28', 'amber-dark': '#FF8F00',
            'cyan-normal': '#00BCD4', 'cyan-light': '#26C6DA', 'cyan-dark': '#00838F',
            'lime-normal': '#CDDC39', 'lime-light': '#D4E157', 'lime-dark': '#9E9D24'
        };
        return colors[colorName] || '#2196F3';
    }

    isOnline(user) {
        try {
            const lastSeen = new Date(user.last_seen);
            const now = new Date();
            return (now - lastSeen) < 5 * 60 * 1000;
        } catch {
            return false;
        }
    }

    closeModal(e) {
        const modal = e.target.closest('.modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }
}

// Глобальные функции для авторизации
async function handleLogin() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    
    if (!username || !password) {
        showAuthError('Заполните все поля');
        return;
    }
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();
        
        if (data.success) {
            window.location.reload();
        } else {
            showAuthError(data.error);
        }
    } catch (error) {
        showAuthError('Ошибка соединения');
    }
}

async function handleRegister() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    const passwordConfirm = document.getElementById('register-password-confirm').value;

    if (!username || !password || !passwordConfirm) {
        showAuthError('Заполните все поля');
        return;
    }

    if (password !== passwordConfirm) {
        showAuthError('Пароли не совпадают');
        return;
    }

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, password_confirm: passwordConfirm })
        });

        const data = await response.json();
        
        if (data.success) {
            window.location.reload();
        } else {
            showAuthError(data.error);
        }
    } catch (error) {
        showAuthError('Ошибка соединения');
    }
}

function showAuthError(message) {
    const errorContainer = document.getElementById('auth-error');
    if (errorContainer) {
        errorContainer.textContent = message;
        errorContainer.style.display = 'block';
        setTimeout(() => {
            errorContainer.style.display = 'none';
        }, 5000);
    }
}

function switchAuthTab(tabName) {
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    const form = document.getElementById(tabName + '-form');
    const button = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    
    if (form) form.classList.add('active');
    if (button) button.classList.add('active');
    
    const errorContainer = document.getElementById('auth-error');
    if (errorContainer) errorContainer.style.display = 'none';
}

// Глобальные функции для HTML
function showUserProfile(userId) {
    if (window.messenger) window.messenger.showUserProfile(userId);
}

function mentionUser(username) {
    const input = document.getElementById('message-input');
    if (input) {
        input.value = input.value + `@${username} `;
        input.focus();
    }
}

// Инициализация
let messenger;
document.addEventListener('DOMContentLoaded', () => {
    messenger = new Messenger();
});