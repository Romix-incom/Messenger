from flask import Flask, render_template, request, jsonify, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import json
import os
import uuid
from datetime import datetime
from functools import wraps

app = Flask(__name__, template_folder='templates')
app.secret_key = 'your-secret-key-here'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB max file size

# Пути к файлам данных
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
MESSAGES_FILE = os.path.join(DATA_DIR, 'messages.json')
MENTIONS_FILE = os.path.join(DATA_DIR, 'mentions.json')

# Создаем директории если их нет
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs('static/avatars', exist_ok=True)
os.makedirs('static/photos', exist_ok=True)
os.makedirs('static/voices', exist_ok=True)
os.makedirs('templates', exist_ok=True)

# Инициализация файлов данных
def init_data_files():
    default_data = {
        'users': [],
        'messages': [],
        'mentions': []
    }
    
    for file_path, key in [(USERS_FILE, 'users'), (MESSAGES_FILE, 'messages'), (MENTIONS_FILE, 'mentions')]:
        if not os.path.exists(file_path):
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump({key: []}, f, ensure_ascii=False, indent=2)

init_data_files()

# Декоратор для проверки авторизации
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Требуется авторизация'}), 401
        return f(*args, **kwargs)
    return decorated_function

# Вспомогательные функции для работы с данными
def read_json(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if not content:
                return {}
            data = json.loads(content)
            if isinstance(data, list):
                if 'users' in file_path:
                    return {'users': data}
                elif 'messages' in file_path:
                    return {'messages': data}
                elif 'mentions' in file_path:
                    return {'mentions': data}
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        return {}
    except Exception as e:
        print(f"Ошибка чтения файла {file_path}: {e}")
        return {}

def write_json(file_path, data):
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Ошибка записи в файл {file_path}: {e}")

def get_users():
    data = read_json(USERS_FILE)
    return data.get('users', [])

def get_messages():
    data = read_json(MESSAGES_FILE)
    return data.get('messages', [])

def get_mentions():
    data = read_json(MENTIONS_FILE)
    return data.get('mentions', [])

def save_users(users):
    write_json(USERS_FILE, {'users': users})

def save_messages(messages):
    write_json(MESSAGES_FILE, {'messages': messages})

def save_mentions(mentions):
    write_json(MENTIONS_FILE, {'mentions': mentions})

# Маршруты
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

# API endpoints
@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Неверный формат данных'}), 400
            
        username = data.get('username', '').strip()
        password = data.get('password', '')
        password_confirm = data.get('password_confirm', '')

        if not username or not password:
            return jsonify({'error': 'Заполните все поля'}), 400

        if password != password_confirm:
            return jsonify({'error': 'Пароли не совпадают'}), 400

        if len(username) < 3:
            return jsonify({'error': 'Логин должен содержать минимум 3 символа'}), 400

        if len(password) < 6:
            return jsonify({'error': 'Пароль должен содержать минимум 6 символов'}), 400

        users = get_users()
        if any(user['username'].lower() == username.lower() for user in users):
            return jsonify({'error': 'Пользователь с таким логином уже существует'}), 400

        user_id = str(uuid.uuid4())
        new_user = {
            'id': user_id,
            'username': username,
            'password_hash': generate_password_hash(password),
            'avatar': 'default.png',
            'description': '',
            'color': 'blue-normal',
            'created_at': datetime.now().isoformat(),
            'last_seen': datetime.now().isoformat()
        }

        users.append(new_user)
        save_users(users)

        session['user_id'] = user_id
        return jsonify({'success': True, 'user_id': user_id})
        
    except Exception as e:
        print(f"Ошибка регистрации: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Неверный формат данных'}), 400
            
        username = data.get('username', '').strip()
        password = data.get('password', '')

        if not username or not password:
            return jsonify({'error': 'Заполните все поля'}), 400

        users = get_users()
        user = next((u for u in users if u['username'].lower() == username.lower()), None)

        if not user or not check_password_hash(user['password_hash'], password):
            return jsonify({'error': 'Неверный логин или пароль'}), 401

        # Обновляем время последнего входа
        user['last_seen'] = datetime.now().isoformat()
        save_users(users)

        session['user_id'] = user['id']
        return jsonify({'success': True, 'user_id': user['id']})
        
    except Exception as e:
        print(f"Ошибка входа: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    session.pop('user_id', None)
    return jsonify({'success': True})

@app.route('/api/profile', methods=['GET', 'POST'])
@login_required
def profile():
    try:
        if request.method == 'GET':
            users = get_users()
            user = next((u for u in users if u['id'] == session['user_id']), None)
            if user:
                user_data = user.copy()
                user_data.pop('password_hash', None)
                return jsonify(user_data)
            return jsonify({'error': 'Пользователь не найден'}), 404

        else:  # POST
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Неверный формат данных'}), 400
                
            description = data.get('description', '').strip()
            color = data.get('color', 'blue-normal')
            avatar = data.get('avatar', 'default.png')

            users = get_users()
            user_index = next((i for i, u in enumerate(users) if u['id'] == session['user_id']), -1)

            if user_index == -1:
                return jsonify({'error': 'Пользователь не найден'}), 404

            users[user_index]['description'] = description
            users[user_index]['color'] = color
            users[user_index]['avatar'] = avatar
            users[user_index]['last_seen'] = datetime.now().isoformat()
            save_users(users)

            return jsonify({'success': True})
            
    except Exception as e:
        print(f"Ошибка профиля: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/user/<user_id>')
@login_required
def get_user(user_id):
    try:
        users = get_users()
        user = next((u for u in users if u['id'] == user_id), None)
        if user:
            user_data = user.copy()
            user_data.pop('password_hash', None)
            return jsonify(user_data)
        return jsonify({'error': 'Пользователь не найден'}), 404
    except Exception as e:
        print(f"Ошибка получения пользователя: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/messages', methods=['GET', 'POST'])
@login_required
def messages():
    try:
        if request.method == 'GET':
            messages = get_messages()
            return jsonify({'messages': messages or []})
        
        else:  # POST
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Неверный формат данных'}), 400
                
            text = data.get('text', '').strip()
            reply_to = data.get('reply_to')
            message_type = data.get('type', 'text')

            if not text and message_type == 'text':
                return jsonify({'error': 'Сообщение не может быть пустым'}), 400

            if len(text) > 1000:
                return jsonify({'error': 'Сообщение слишком длинное'}), 400

            users = get_users()
            current_user = next((u for u in users if u['id'] == session['user_id']), None)

            if not current_user:
                return jsonify({'error': 'Пользователь не найден'}), 404

            message_id = str(uuid.uuid4())
            new_message = {
                'id': message_id,
                'user_id': session['user_id'],
                'username': current_user['username'],
                'avatar': current_user['avatar'],
                'color': current_user['color'],
                'text': text,
                'type': message_type,
                'reply_to': reply_to,
                'timestamp': datetime.now().isoformat(),
                'mentions': []
            }

            # Поиск упоминаний
            if '@' in text:
                words = text.split()
                mentions = [word[1:] for word in words if word.startswith('@') and len(word) > 1]
                
                for mention in mentions:
                    mentioned_user = next((u for u in users if u['username'].lower() == mention.lower()), None)
                    if mentioned_user:
                        new_message['mentions'].append(mentioned_user['id'])
                        
                        # Сохраняем упоминание
                        mentions_data = get_mentions()
                        new_mention = {
                            'id': str(uuid.uuid4()),
                            'message_id': message_id,
                            'mentioned_user_id': mentioned_user['id'],
                            'mentioning_user_id': session['user_id'],
                            'mentioning_username': current_user['username'],
                            'message_text': text,
                            'timestamp': datetime.now().isoformat(),
                            'read': False
                        }
                        mentions_data.append(new_mention)
                        save_mentions(mentions_data)

            messages_data = get_messages()
            messages_data.append(new_message)
            save_messages(messages_data)

            return jsonify({'success': True, 'message_id': message_id})
            
    except Exception as e:
        print(f"Ошибка сообщений: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/upload/avatar', methods=['POST'])
@login_required
def upload_avatar():
    try:
        if 'avatar' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['avatar']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400

        if file and allowed_file(file.filename, ['png', 'jpg', 'jpeg', 'gif']):
            filename = secure_filename(f"{session['user_id']}_{file.filename}")
            file_path = os.path.join('static', 'avatars', filename)
            file.save(file_path)
            
            # Обновляем аватар пользователя
            users = get_users()
            user_index = next((i for i, u in enumerate(users) if u['id'] == session['user_id']), -1)
            if user_index != -1:
                users[user_index]['avatar'] = filename
                save_users(users)
            
            return jsonify({'success': True, 'filename': filename})
        
        return jsonify({'error': 'Недопустимый формат файла'}), 400
        
    except Exception as e:
        print(f"Ошибка загрузки аватара: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/upload/photo', methods=['POST'])
@login_required
def upload_photo():
    try:
        if 'photo' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['photo']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400

        if file and allowed_file(file.filename, ['png', 'jpg', 'jpeg', 'gif']):
            filename = secure_filename(f"{session['user_id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
            file.save(os.path.join('static', 'photos', filename))
            return jsonify({'success': True, 'filename': filename})
        
        return jsonify({'error': 'Недопустимый формат файла'}), 400
        
    except Exception as e:
        print(f"Ошибка загрузки фото: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/upload/voice', methods=['POST'])
@login_required
def upload_voice():
    try:
        if 'voice' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['voice']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400

        if file and allowed_file(file.filename, ['mp3', 'wav', 'ogg', 'm4a', 'webm']):
            filename = secure_filename(f"{session['user_id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
            file_path = os.path.join('static', 'voices', filename)
            file.save(file_path)
            
            # Простая реализация определения длительности
            duration = 5  # значение по умолчанию
                
            return jsonify({
                'success': True, 
                'filename': filename,
                'duration': duration
            })
        
        return jsonify({'error': 'Недопустимый формат файла'}), 400
        
    except Exception as e:
        print(f"Ошибка загрузки голоса: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/voice/<filename>')
@login_required
def get_voice(filename):
    return send_from_directory('static/voices', filename)

@app.route('/api/search/messages', methods=['POST'])
@login_required
def search_messages():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Неверный формат данных'}), 400
            
        query = data.get('query', '').strip().lower()
        
        if not query:
            return jsonify({'error': 'Введите поисковый запрос'}), 400

        messages = get_messages()
        results = []
        
        for msg in messages:
            if query in msg.get('text', '').lower():
                results.append(msg)
        
        return jsonify({'results': results})
        
    except Exception as e:
        print(f"Ошибка поиска: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/mentions', methods=['GET', 'POST'])
@login_required
def get_user_mentions():
    try:
        if request.method == 'POST':
            # Пометить все упоминания как прочитанные
            data = request.get_json()
            mention_ids = data.get('mention_ids', [])
            
            mentions = get_mentions()
            for mention in mentions:
                if mention['id'] in mention_ids:
                    mention['read'] = True
            save_mentions(mentions)
            return jsonify({'success': True})
        
        else:  # GET
            mentions = get_mentions()
            user_mentions = [m for m in mentions if m['mentioned_user_id'] == session['user_id']]
            
            # Сортируем по времени (новые сначала)
            user_mentions.sort(key=lambda x: x['timestamp'], reverse=True)
            
            return jsonify({'mentions': user_mentions})
        
    except Exception as e:
        print(f"Ошибка упоминаний: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/users')
@login_required
def get_all_users():
    try:
        users = get_users()
        for user in users:
            user.pop('password_hash', None)
        return jsonify({'users': users})
    except Exception as e:
        print(f"Ошибка получения пользователей: {e}")
        return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.route('/api/check_auth')
def check_auth():
    try:
        if 'user_id' in session:
            users = get_users()
            user = next((u for u in users if u['id'] == session['user_id']), None)
            if user:
                user_data = user.copy()
                user_data.pop('password_hash', None)
                return jsonify({'authenticated': True, 'user': user_data})
        return jsonify({'authenticated': False})
    except Exception as e:
        print(f"Ошибка проверки авторизации: {e}")
        return jsonify({'authenticated': False})

def allowed_file(filename, allowed_extensions):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

# Функция для исправления формата JSON файлов
def fix_json_files():
    for file_path in [USERS_FILE, MESSAGES_FILE, MENTIONS_FILE]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:
                    continue
                    
                data = json.loads(content)
                if isinstance(data, list):
                    if 'users' in file_path:
                        new_data = {'users': data}
                    elif 'messages' in file_path:
                        new_data = {'messages': data}
                    elif 'mentions' in file_path:
                        new_data = {'mentions': data}
                    else:
                        continue
                        
                    with open(file_path, 'w', encoding='utf-8') as fw:
                        json.dump(new_data, fw, ensure_ascii=False, indent=2)
                    print(f"Исправлен формат файла: {file_path}")
                    
        except (json.JSONDecodeError, FileNotFoundError):
            continue
        except Exception as e:
            print(f"Ошибка исправления файла {file_path}: {e}")

# Создаем дефолтный аватар
def create_default_avatar():
    default_avatar_path = os.path.join('static', 'avatars', 'default.png')
    if not os.path.exists(default_avatar_path):
        try:
            # Просто создаем пустой файл
            with open(default_avatar_path, 'wb') as f:
                f.write(b'')
        except Exception as e:
            print(f"Ошибка создания дефолтного аватара: {e}")

# Исправляем файлы при запуске
fix_json_files()
create_default_avatar()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)